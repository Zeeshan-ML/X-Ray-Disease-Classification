from flask import Flask, render_template, request
import tensorflow as tf
from tensorflow.keras.preprocessing.image import img_to_array, load_img # type: ignore
import numpy as np
import os

app = Flask(__name__)

model = tf.keras.models.load_model("C:\\Users\\Zeeshan\\Downloads\\pneumonia-covid.h5")

upload_folder = os.path.join('static', 'uploads')
if not os.path.exists(upload_folder):
    os.makedirs(upload_folder)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        file = request.files['file']
        if file:
            try:

                file_path = os.path.join(upload_folder, file.filename)
                file.save(file_path)

                image = load_img(file_path, target_size=(128, 128))
                image = np.expand_dims(image, axis=0)             
                prediction = model.predict(image)
                result = interpret_prediction(prediction)              
                return render_template('upload.html', prediction=result, image_path=file_path)
            except Exception as e:
                return render_template('upload.html', prediction=f"Error: {e}", image_path=None)

    return render_template('upload.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

def interpret_prediction(prediction):
    labels = ['COVID', 'NORMAL', 'PNEUMONIA']
    predicted_class_index = np.argmax(prediction)
    return labels[predicted_class_index]

if __name__ == '__main__':
    app.run(debug=True)
